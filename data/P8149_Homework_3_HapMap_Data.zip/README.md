# P8149 Homework 3 HapMap Data

The archive contains `hapmap_snprelate_ld_pruned.rds`.

The R object contains:

- `genotype`: a 279 by 6,132 matrix of autosomal genotypes coded as 0, 1, or 2 copies of the counted allele. Row names are sample IDs.
- `sample_annot`: sample ID, population, sex, family ID, father ID, and mother ID for 279 HapMap samples from CEU, HCB, JPT, and YRI.
- `original_snps`: 9,088 autosomal SNPs before LD pruning.
- `ld_threshold`: the LD-pruning threshold, r-squared = 0.2.
- `source`: the HapMap example distributed with SNPRelate.

Load the file in R:

```r
hapmap <- readRDS("hapmap_snprelate_ld_pruned.rds")
genotype <- hapmap$genotype
sample_annot <- hapmap$sample_annot

dim(genotype)
head(sample_annot)
```

The course vignette gives the model definitions and a worked code example:

https://statfungen.github.io/P8149_2026_vignettes/p8149-lecture-3-genome-wide-kinship/
